# Deployment snapshot

This repository is a source-and-configuration backup of the Moonletter deployment.

It intentionally excludes all runtime data and credentials. To deploy, create a
restricted environment file on the host containing `PROJECT_ID` and
`PROJECT_SECRET`; never commit that file.

The `deploy/` directory contains the systemd and Nginx configuration used for
the Ubuntu deployment. The application state is not part of this repository.
